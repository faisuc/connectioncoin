<html>
    <head>
        <title>Connection Coin</title>
        <link rel="stylesheet" href="https://abs.twimg.com/a/1566865267/css/t1/twitter_core.bundle.css">
        <link rel="stylesheet" href="https://abs.twimg.com/a/1566865267/css/t1/twitter_more_1.bundle.css">
        <link rel="stylesheet" href="https://abs.twimg.com/a/1566865267/css/t1/twitter_more_2.bundle.css">
    </head>
    <body class="three-col logged-out ms-windows static-logged-out-home-page no-nav-banners" data-fouc-class-names="swift-loading no-nav-banners" dir="ltr">
      <div id="doc" data-at-shortcutkeys="{&quot;Enter&quot;:&quot;Open Tweet details&quot;,&quot;o&quot;:&quot;Expand photo&quot;,&quot;/&quot;:&quot;Search&quot;,&quot;?&quot;:&quot;This menu&quot;,&quot;j&quot;:&quot;Next Tweet&quot;,&quot;k&quot;:&quot;Previous Tweet&quot;,&quot;Space&quot;:&quot;Page down&quot;,&quot;.&quot;:&quot;Load new Tweets&quot;,&quot;gu&quot;:&quot;Go to user\u2026&quot;}" class="">
          <div class="StaticLoggedOutHomePage">
    <div class="StaticLoggedOutHomePage-content">
      <div class="StaticLoggedOutHomePage-cell StaticLoggedOutHomePage-utilityBlock">
        <div class="StaticLoggedOutHomePage-login">
  {{-- <form action="https://twitter.com/sessions" class="LoginForm js-front-signin" method="post" data-component="login_callout" data-element="form">
    <div class="LoginForm-input LoginForm-username">
      <input type="text" class="text-input email-input js-signin-email" name="session[username_or_email]" autocomplete="off" placeholder="Phone, email, or username" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
    </div>
  
    <div class="LoginForm-input LoginForm-password">
      <input type="password" class="text-input" name="session[password]" placeholder="Password" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                  <div class="LoginForm-staticForgot">
                <a class="forgot" href="/account/begin_password_reset" rel="noopener">Forgot password?</a>
              </div>
  
    </div>
  
  
    <input type="submit" class="EdgeButton EdgeButton--secondary EdgeButton--medium submit js-submit" value="Log in">
  
      <input type="hidden" name="return_to_ssl" value="true">
  
    <input type="hidden" name="scribe_log">
    <input type="hidden" name="redirect_after_login" value="/">
    <input type="hidden" value="9d3268678628b16135be2e5a26e81ec9db378111" name="authenticity_token">
        <input type="hidden" name="ui_metrics" autocomplete="off" value="{&quot;rf&quot;:{&quot;dcf03db7356e3341a8a1a931a627b0ec45400ad4f132622d9314c2bbf696d210&quot;:-19,&quot;a650416bb5fd235583edc9f90ee4ca34cc71a3bb8be61d1517275854a16b2e8a&quot;:64,&quot;abc8a39ba31d49db36884b6e838d616be83dbba8c483acab26ece75f57a34389&quot;:175,&quot;ca3f20952f4d5e7ec2d1828f608da76eb19df250b5acc8b08b6fa564c3824578&quot;:190},&quot;s&quot;:&quot;mDZe9ZVm9qHinbGM_6AgrthAlsVk0D2KU4mIxqUnK8Nc2Y0PwW0PAU31mRSfWi-jSfsV1IKhuhxfV9Gw-IyU22wmJTy1dnxuwARdiNfksYjOXS_WZf7LA4J3Y1eAH89gAeqnZvNuxj8IvKtWPGK_v8LfBjBZRz0UU5S1aJFU9zxDpEG3aHtw-i7iDEWqtpqw4Lfjvs5INA01gXPRFYjTvi9aFzfbSSv9qS34ixZaviHNswMr0bdsIlnw_K_EnIKf4mchnR2sds7xQoUpuKhjY66pb0SHBOrI_0UsM_bNU5WQOWZ-Azblr3tpZP8-rG_OEORSzk4RnjT2j5XknmTQ4gAAAWzXkcnF&quot;}">
        <script src="/i/js_inst?c_name=ui_metrics" async=""></script>
  </form> --}}
        </div>
        <div class="StaticLoggedOutHomePage-signupBlock">
          {{-- <div class="StaticLoggedOutHomePage-signupHeader">
            <span class="Icon Icon--bird"></span>
            <a class="StaticLoggedOutHomePage-input StaticLoggedOutHomePage-narrowLoginButton EdgeButton EdgeButton--secondary EdgeButton--small u-floatRight" href="/login">
              Log in
            </a>
          </div> --}}
          <h1 class="StaticLoggedOutHomePage-signupTitle">See what’s happening in the world right now</h1>
            <div class="StaticLoggedOutHomePage-noSignupForm">
              <h2 class="StaticLoggedOutHomePage-signupSubtitle">Join Connection Coin today.</h2>
              <div class="StaticLoggedOutHomePage-buttons">
                <a class="js-nav EdgeButton EdgeButton--medium EdgeButton--primary StaticLoggedOutHomePage-buttonSignup" href="{{ route('register') }}" style="background-color: #0085ad !important;">
                  Sign up
                </a>
                <a class="js-nav EdgeButton EdgeButton--medium EdgeButton--secondary StaticLoggedOutHomePage-buttonLogin" href="{{ route('login') }}" style="color: #0085ad; border-color: #0085ad;">
                  Log in
                </a>
              </div>
            </div>
        </div>
      </div>
  
      <div class="StaticLoggedOutHomePage-cell StaticLoggedOutHomePage-communicationBlock" style="background-color: #0085ad !important;">

        <div class="StaticLoggedOutHomePage-communicationContent">
            <img src="{{ asset('images/connectioncoin_logo.png') }}" class="img-responsive" width="100%" />
            <div class="StaticLoggedOutHomePage-delightHeader">
              A global community of individuals who believe that connecting with others changes everything.
              <iframe src="https://player.vimeo.com/video/358317165" width="100%" height="280px" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
            </div>
        </div>
      </div>
    </div>
  
  
    <noscript>
    <div class="front-warning">
      <h3>Twitter.com makes heavy use of JavaScript</h3>
      <p>If you cannot enable it in your browser's preferences, you may have a better experience on our <a href="http://m.twitter.com" rel="noopener">mobile site</a>.</p>
    </div>
  </noscript>
  
  <div class="front-warning" id="front-no-cookies-warn">
    <h3>Twitter.com makes heavy use of browser cookies</h3>
    <p>Please enable cookies in your browser preferences before signing in.</p>
  </div>
    {{-- <div class="StreamsFooter StreamsFooter--fixed">
    <ul class="StreamsFooter-list u-cf">
      <li class="StreamsFooter-item"><a href="/about" rel="noopener">About</a></li>
      <li class="StreamsFooter-item"><a href="//support.twitter.com" rel="noopener">Help Center</a></li>
      <li class="StreamsFooter-item"><a href="https://blog.twitter.com" rel="noopener">Blog</a></li>
      <li class="StreamsFooter-item"><a href="http://status.twitter.com" rel="noopener">Status</a></li>
      <li class="StreamsFooter-item"><a href="https://about.twitter.com/careers" rel="noopener">Jobs</a></li>
      <li class="StreamsFooter-item"><a href="/tos" rel="noopener">Terms</a></li>
      <li class="StreamsFooter-item"><a href="/privacy" rel="noopener">Privacy Policy</a></li>
      <li class="StreamsFooter-item"><a href="//support.twitter.com/articles/20170514" rel="noopener">Cookies</a></li>
      <li class="StreamsFooter-item"><a href="//business.twitter.com/en/help/troubleshooting/how-twitter-ads-work.html" rel="noopener">Ads info</a></li>
      <li class="StreamsFooter-item"><a href="//about.twitter.com/press/brand-assets" rel="noopener">Brand</a></li>
      <li class="StreamsFooter-item"><a href="https://about.twitter.com/products" rel="noopener">Apps</a></li>
      <li class="StreamsFooter-item"><a href="//ads.twitter.com/?ref=gl-tw-tw-twitter-advertise" rel="noopener">Advertise</a></li>
      <li class="StreamsFooter-item"><a href="https://marketing.twitter.com" rel="noopener">Marketing</a></li>
      <li class="StreamsFooter-item"><a href="https://business.twitter.com" rel="noopener">Businesses</a></li>
      <li class="StreamsFooter-item"><a href="//dev.twitter.com" rel="noopener">Developers</a></li>
      <li class="StreamsFooter-item"><a href="/i/directory/profiles" rel="noopener">Directory</a></li>
      <li class="StreamsFooter-item"><a href="/settings/personalization" rel="noopener">Settings</a></li>
      <li class="StreamsFooter-item StreamsFooter-copyright">© 2019 Twitter</li>
    </ul>
  </div>
   --}}
  </div>
  
      </div>
      <div class="alert-messages hidden" id="message-drawer" style="top: -40px;">
      <div class="message ">
    <div class="message-inside">
      <span class="message-text"></span>
        <a role="button" class="Icon Icon--close Icon--medium dismiss" href="#">
          <span class="visuallyhidden">Dismiss</span>
        </a>
    </div>
  </div>
  </div>
  
      
  
  
  <div class="gallery-overlay"></div>
  <div class="Gallery with-tweet">
    <style class="Gallery-styles"></style>
    <div class="Gallery-closeTarget"></div>
    <div class="Gallery-content">
      <div class="GalleryTweet-newsCameraBadge"></div>
      <button type="button" class="modal-btn modal-close modal-close-fixed js-close">
    <span class="Icon Icon--close Icon--large">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
      <div class="Gallery-media"></div>
      <div class="GalleryNav GalleryNav--prev">
        <span class="GalleryNav-handle GalleryNav-handle--prev">
          <span class="Icon Icon--caretLeft Icon--large">
            <span class="u-hiddenVisually">
              Previous
            </span>
          </span>
        </span>
      </div>
      <div class="GalleryNav GalleryNav--next">
        <span class="GalleryNav-handle GalleryNav-handle--next">
          <span class="Icon Icon--caretRight Icon--large">
            <span class="u-hiddenVisually">
              Next
            </span>
          </span>
        </span>
      </div>
      <div class="GalleryTweet"></div>
    </div>
  </div>
  
  
  <div class="modal-overlay"></div>
  
  <div id="profile-hover-container"></div>
  
  
  <div id="goto-user-dialog" class="modal-container">
    <div class="modal modal-small draggable">
      <div class="modal-content">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
  
        <div class="modal-header">
          <h3 class="modal-title">Go to a person's profile</h3>
        </div>
  
        <div class="modal-body">
          <div class="modal-inner">
            <form class="t1-form goto-user-form">
              <input class="input-block username-input" type="text" placeholder="Start typing a name to jump to a profile" aria-label="User">
              
  
  
  <div role="listbox" class="dropdown-menu typeahead">
    <div aria-hidden="true" class="dropdown-caret">
      <div class="caret-outer"></div>
      <div class="caret-inner"></div>
    </div>
    <div role="presentation" class="dropdown-inner js-typeahead-results">
      <div role="presentation" class="typeahead-saved-searches">
    <h3 id="saved-searches-heading" class="typeahead-category-title saved-searches-title">Saved searches</h3>
    <ul role="presentation" class="typeahead-items saved-searches-list">
      
      <li role="presentation" class="typeahead-item typeahead-saved-search-item">
        <span class="Icon Icon--close" aria-hidden="true"><span class="visuallyhidden">Remove</span></span>
        <a role="option" aria-describedby="saved-searches-heading" class="js-nav" href="" data-search-query="" data-query-source="" data-ds="saved_search" tabindex="-1"></a>
      </li>
    </ul>
  </div>
  
      <ul role="presentation" class="typeahead-items typeahead-topics">
    
    <li role="presentation" class="typeahead-item typeahead-topic-item">
      <a role="option" class="js-nav" href="" data-search-query="" data-query-source="typeahead_click" data-ds="topics" tabindex="-1"></a>
    </li>
  </ul>
      <ul role="presentation" class="typeahead-items typeahead-accounts social-context js-typeahead-accounts">
    
    <li role="presentation" data-user-id="" data-user-screenname="" data-remote="true" data-score="" class="typeahead-item typeahead-account-item js-selectable">
      
      <a role="option" class="js-nav" data-query-source="typeahead_click" data-search-query="" data-ds="account">
        <div class="js-selectable typeahead-in-conversation hidden">
          <span class="Icon Icon--follower Icon--small"></span>
          <span class="typeahead-in-conversation-text">In this conversation</span>
        </div>
        <img class="avatar size32" alt="">
        <span class="typeahead-user-item-info account-group">
          <span class="fullname"></span><span class="UserBadges"><span class="Icon Icon--verified js-verified hidden"><span class="u-hiddenVisually">Verified account</span></span><span class="Icon Icon--protected js-protected hidden"><span class="u-hiddenVisually">Protected Tweets</span></span></span><span class="UserNameBreak">&nbsp;</span><span class="username u-dir" dir="ltr">@<b></b></span>
        </span>
        <span class="typeahead-social-context"></span>
      </a>
    </li>
    <li role="presentation" class="js-selectable typeahead-accounts-shortcut js-shortcut"><a role="option" class="js-nav" href="" data-search-query="" data-query-source="typeahead_click" data-shortcut="true" data-ds="account_search"></a></li>
  </ul>
  
      <ul role="presentation" class="typeahead-items typeahead-trend-locations-list">
    
    <li role="presentation" class="typeahead-item typeahead-trend-locations-item"><a role="option" class="js-nav" href="" data-ds="trend_location" data-search-query="" tabindex="-1"></a></li>
  </ul>
      
  <div role="presentation" class="typeahead-user-select">
    <div role="presentation" class="typeahead-empty-suggestions">
      Suggested users
    </div>
    <ul role="presentation" class="typeahead-items typeahead-selected js-typeahead-selected">
      
      <li role="presentation" data-user-id="" data-user-screenname="" data-remote="true" data-score="" class="typeahead-item typeahead-selected-item js-selectable">
        
        <a role="option" class="js-nav" data-query-source="typeahead_click" data-search-query="" data-ds="account">
          <img class="avatar size32" alt="">
          <span class="typeahead-user-item-info account-group">
            <span class="select-status deselect-user js-deselect-user Icon Icon--check"></span>
            <span class="select-status select-disabled Icon Icon--unfollow"></span>
            <span class="fullname"></span><span class="UserBadges"><span class="Icon Icon--verified js-verified hidden"><span class="u-hiddenVisually">Verified account</span></span><span class="Icon Icon--protected js-protected hidden"><span class="u-hiddenVisually">Protected Tweets</span></span></span><span class="UserNameBreak">&nbsp;</span><span class="username u-dir" dir="ltr">@<b></b></span>
          </span>
        </a>
      </li>
      <li role="presentation" class="typeahead-selected-end"></li>
    </ul>
  
    <ul role="presentation" class="typeahead-items typeahead-accounts js-typeahead-accounts">
      
      <li role="presentation" data-user-id="" data-user-screenname="" data-remote="true" data-score="" class="typeahead-item typeahead-account-item js-selectable">
        
        <a role="option" class="js-nav" data-query-source="typeahead_click" data-search-query="" data-ds="account">
          <img class="avatar size32" alt="">
          <span class="typeahead-user-item-info account-group">
            <span class="select-status deselect-user js-deselect-user Icon Icon--check"></span>
            <span class="select-status select-disabled Icon Icon--unfollow"></span>
            <span class="fullname"></span><span class="UserBadges"><span class="Icon Icon--verified js-verified hidden"><span class="u-hiddenVisually">Verified account</span></span><span class="Icon Icon--protected js-protected hidden"><span class="u-hiddenVisually">Protected Tweets</span></span></span><span class="UserNameBreak">&nbsp;</span><span class="username u-dir" dir="ltr">@<b></b></span>
          </span>
        </a>
      </li>
      <li role="presentation" class="typeahead-accounts-end"></li>
    </ul>
  </div>
  
      <div role="presentation" class="typeahead-dm-conversations">
    <ul role="presentation" class="typeahead-items typeahead-dm-conversation-items">
      <li role="presentation" class="typeahead-item typeahead-dm-conversation-item">
        <a role="option" tabindex="-1"></a>
      </li>
    </ul>
  </div>
    </div>
  </div>
  
            </form>
          </div>
        </div>
  
      </div>
    </div>
  </div>
  
  <div id="quick-promote-dialog" class="QuickPromoteDialog modal-container">
    <div class="modal draggable">
      <div class="modal-content">
        <button type="button" class="modal-btn modal-close modal-close-fixed js-close">
    <span class="Icon Icon--close Icon--large">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
        <div class="modal-header">
          <h3 class="modal-title">Promote this Tweet</h3>
        </div>
        <div class="modal-body">
          <div class="quick-promote-view-container">
            <div class="media">
              <iframe class="quick-promote-iframe js-initial-focus" scrolling="no" frameborder="0" src="">
              </iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
  <div id="block-user-dialog" class="modal-container">
    <div class="modal draggable">
      <div class="modal-content">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
  
        <div class="modal-header">
          <h3 class="modal-title">Block</h3>
        </div>
  
        <div class="tweet-loading">
    <div class="spinner-bigger"></div>
  </div>
  
        <div class="modal-body modal-tweet"></div>
  
        <div class="modal-footer">
          <button class="EdgeButton EdgeButton--tertiary cancel-action js-close">Cancel</button>
          <button class="EdgeButton EdgeButton--danger block-action">Block</button>
        </div>
      </div>
    </div>
  </div>
  
  
  
  
  
  
     <div id="geo-disabled-dropdown">
      <div tabindex="-1">
    <div class="dropdown-caret">
      <span class="caret-outer"></span>
      <span class="caret-inner"></span>
    </div>
    <ul>
      <li class="geo-not-enabled-yet">
        <h2>Tweet with a location</h2>
        <p>
          You can add location information to your Tweets, such as your city or precise location, from the web and via third-party applications. You always have the option to delete your Tweet location history.
          <a href="http://support.twitter.com/forums/26810/entries/78525" target="_blank" rel="noopener">Learn more</a>
        </p>
        <div>
          <button type="button" class="geo-turn-on EdgeButton EdgeButton--primary">Turn on</button>
          <button type="button" class="geo-not-now EdgeButton EdgeButton--secondary">Not now</button>
        </div>
      </li>
    </ul>
  </div>
  
    </div>
  
  <div id="geo-enabled-dropdown">
    <div tabindex="-1">
    <div class="dropdown-caret">
      <span class="caret-outer"></span>
      <span class="caret-inner"></span>
    </div>
    <div>
      <div class="geo-query-location">
        <input class="GeoSearch-queryInput" type="text" autocomplete="off" placeholder="Search for a neighborhood or city">
        <span class="Icon Icon--search"></span>
      </div>
      <div class="geo-dropdown-status"></div>
      <ul class="GeoSearch-dropdownMenu"></ul>
    </div>
  </div>
  
  </div>
  
  
  
    <div id="list-membership-dialog" class="modal-container">
    <div class="modal modal-small draggable">
      <div class="modal-content">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
        <div class="modal-header">
          <h3 class="modal-title">Your lists</h3>
        </div>
        <div class="modal-body">
          <div class="list-membership-content"></div>
          <span class="spinner lists-spinner" title="Loading…"></span>
        </div>
      </div>
    </div>
  </div>
    <div id="list-operations-dialog" class="modal-container">
    <div class="modal modal-medium draggable">
      <div class="modal-content">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
        <div class="modal-header">
          <h3 class="modal-title">Create a new list</h3>
        </div>
        <div class="modal-body">
          <div class="list-editor">
    <div class="field">
      <label class="t1-label" for="list-name">List name</label>
      <input id="list-name" type="text" class="text" name="name" value="">
    </div>
    <hr>
  
    <div class="field">
      <label class="t1-label" for="list-description">Description</label>
      <textarea id="list-description" name="description"></textarea>
      <span class="help-text">Under 100 characters, optional</span>
    </div>
    <hr>
  
    <fieldset class="field">
      <legend class="t1-legend">Privacy</legend>
      <div class="options">
        <label class="t1-label" for="list-public-radio">
          <input class="radio" type="radio" name="mode" id="list-public-radio" value="public" checked="checked">
          <b>Public</b> · Anyone can follow this list
        </label>
        <label class="t1-label" for="list-private-radio">
          <input class="radio" type="radio" name="mode" id="list-private-radio" value="private">
          <b>Private</b> · Only you can access this list
        </label>
      </div>
    </fieldset>
    <hr>
  
    <div class="list-editor-save">
      <button type="button" class="EdgeButton EdgeButton--secondary update-list-button" data-list-id="">Save list</button>
    </div>
  </div>
  
        </div>
      </div>
    </div>
  </div>
  
  <div id="activity-popup-dialog" class="modal-container">
    <div class="modal draggable">
      <div class="modal-content clearfix">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
  
        <div class="modal-header">
          <h3 class="modal-title"></h3>
        </div>
  
        <div class="modal-body">
          <div class="tweet-loading">
    <div class="spinner-bigger"></div>
  </div>
  
          <div class="activity-popup-dialog-content modal-tweet clearfix"></div>
          <div class="loading">
            <span class="spinner-bigger"></span>
          </div>
          <div class="activity-popup-dialog-users clearfix"></div>
          <div class="activity-popup-dialog-footer"></div>
        </div>
      </div>
    </div>
  </div>
  
  
  
  
  <div id="copy-link-to-tweet-dialog" class="modal-container">
    <div class="modal modal-medium draggable">
      <div class="modal-content">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
        <div class="modal-header">
          <h3 class="modal-title">Copy link to Tweet</h3>
        </div>
        <div class="modal-body">
          <div class="copy-link-to-tweet-container">
            <label class="t1-label">
              <p class="copy-link-to-tweet-instructions">Here's the URL for this Tweet. Copy it to easily share with friends.</p>
              <textarea class="link-to-tweet-destination js-initial-focus u-dir" dir="ltr" readonly=""></textarea>
            </label>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
  <div id="embed-tweet-dialog" class="modal-container">
    <div class="modal modal-medium draggable">
      <div class="modal-content">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
        <div class="modal-header">
          <h3 class="modal-title embed-tweet-title">Embed this Tweet</h3>
          <h3 class="modal-title embed-video-title">Embed this Video</h3>
        </div>
        <div class="modal-body">
          <div class="embed-code-container">
    <p class="embed-tweet-instructions">Add this Tweet to your website by copying the code below. <a href="https://dev.twitter.com/web/embedded-tweets" target="_blank" rel="noopener">Learn more</a></p>
    <p class="embed-video-instructions">Add this video to your website by copying the code below. <a href="https://dev.twitter.com/web/embedded-tweets" target="_blank" rel="noopener">Learn more</a></p>
    <form class="t1-form">
  
      <div class="embed-destination-wrapper">
        <div class="embed-overlay embed-overlay-spinner"><div class="embed-overlay-content"></div></div>
        <div class="embed-overlay embed-overlay-error">
          <p class="embed-overlay-content">Hmm, there was a problem reaching the server. <button type="button" class="btn-link retry-embed">Try again?</button></p>
        </div>
        <textarea class="embed-destination js-initial-focus"></textarea>
        <div class="embed-options">
          <div class="embed-include-parent-tweet">
            <label class="t1-label" for="include-parent-tweet">
              <input type="checkbox" id="include-parent-tweet" class="include-parent-tweet" checked="">
              Include parent Tweet
            </label>
          </div>
          <div class="embed-include-card">
            <label class="t1-label" for="include-card">
              <input type="checkbox" id="include-card" class="include-card" checked="">
              Include media
            </label>
          </div>
        </div>
      </div>
    </form>
    <p class="embed-tweet-description">By embedding Twitter content in your website or app, you are agreeing to the Twitter <a href="https://dev.twitter.com/overview/terms/agreement" rel="noopener">Developer Agreement</a> and <a href="https://dev.twitter.com/overview/terms/policy" rel="noopener">Developer Policy</a>.</p>
    <h3 class="embed-preview-header">Preview</h3>
    <div class="embed-preview">
    </div>
  </div>
  
        </div>
      </div>
    </div>
  </div>
  
  
  <div id="why-this-ad-dialog" class="modal-container why-this-ad-dialog">
    <div class="modal modal-large draggable">
      <div class="modal-content">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
        <div class="modal-header">
          <h3 class="modal-title why-this-ad-title">Why you're seeing this ad</h3>
        </div>
        <div class="why-this-ad-content">
          <div class="why-this-ad-spinner">
            <div class="spinner-bigger"></div>
          </div>
          <iframe id="why-this-ad-frame" class="hidden" aria-hidden="true" scrolling="auto">
          </iframe>
        </div>
      </div>
    </div>
  </div>
  
  
  
    <div id="login-dialog" class="LoginDialog modal-container u-textCenter">
    <div class="modal modal-large draggable">
      <div class="LoginDialog-content modal-content">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
        <div class="modal-header">
          <h3 class="modal-title">Log in to Twitter</h3>
        </div>
        <div class="LoginDialog-body modal-body">
          <div class="LoginDialog-bird">
            <span class="Icon Icon--bird Icon--large"></span>
          </div>
          <div class="LoginDialog-form">
  <form action="https://twitter.com/sessions" class="LoginForm js-front-signin" method="post" data-component="dialog" data-element="login">
    <div class="LoginForm-input LoginForm-username">
      <input type="text" class="text-input email-input js-signin-email" name="session[username_or_email]" autocomplete="off" placeholder="Phone, email, or username" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
    </div>
  
    <div class="LoginForm-input LoginForm-password">
      <input type="password" class="text-input" name="session[password]" placeholder="Password" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
      
    </div>
  
      <div class="LoginForm-rememberForgot">
        <label>
          <input type="checkbox" value="1" name="remember_me" checked="checked">
          <span>Remember me</span>
        </label>
        <span class="separator">·</span>
        <a class="forgot" href="/account/begin_password_reset" rel="noopener">Forgot password?</a>
      </div>
  
    <input type="submit" class="EdgeButton EdgeButton--primary EdgeButton--medium submit js-submit" value="Log in">
  
      <input type="hidden" name="return_to_ssl" value="true">
  
    <input type="hidden" name="scribe_log">
    <input type="hidden" name="redirect_after_login" value="/">
    <input type="hidden" value="9d3268678628b16135be2e5a26e81ec9db378111" name="authenticity_token">
        <input type="hidden" name="ui_metrics" autocomplete="off" value="{&quot;rf&quot;:{&quot;dcf03db7356e3341a8a1a931a627b0ec45400ad4f132622d9314c2bbf696d210&quot;:-19,&quot;a650416bb5fd235583edc9f90ee4ca34cc71a3bb8be61d1517275854a16b2e8a&quot;:64,&quot;abc8a39ba31d49db36884b6e838d616be83dbba8c483acab26ece75f57a34389&quot;:175,&quot;ca3f20952f4d5e7ec2d1828f608da76eb19df250b5acc8b08b6fa564c3824578&quot;:190},&quot;s&quot;:&quot;mDZe9ZVm9qHinbGM_6AgrthAlsVk0D2KU4mIxqUnK8Nc2Y0PwW0PAU31mRSfWi-jSfsV1IKhuhxfV9Gw-IyU22wmJTy1dnxuwARdiNfksYjOXS_WZf7LA4J3Y1eAH89gAeqnZvNuxj8IvKtWPGK_v8LfBjBZRz0UU5S1aJFU9zxDpEG3aHtw-i7iDEWqtpqw4Lfjvs5INA01gXPRFYjTvi9aFzfbSSv9qS34ixZaviHNswMr0bdsIlnw_K_EnIKf4mchnR2sds7xQoUpuKhjY66pb0SHBOrI_0UsM_bNU5WQOWZ-Azblr3tpZP8-rG_OEORSzk4RnjT2j5XknmTQ4gAAAWzXkcnF&quot;}">
        <script src="/i/js_inst?c_name=ui_metrics" async=""></script>
  </form>
          </div>
        </div>
        <div class="LoginDialog-footer modal-footer u-textCenter">
          Don't have an account? <a class="LoginDialog-signupLink" href="https://twitter.com/signup" rel="noopener">Sign up »</a>
        </div>
      </div>
    </div>
  </div>
  
    <div id="signup-dialog" class="SignupDialog modal-container u-textCenter">
    <div class="modal modal-large draggable">
      <div class="SignupDialog-content modal-content">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
        <div class="modal-header">
          <h3 class="modal-title">Sign up for Twitter</h3>
        </div>
        <div class="SignupDialog-body modal-body">
          <div class="SignupDialog-icon">
            <span class="Icon Icon--bird Icon--extraLarge"></span>
          </div>
          <h2 class="SignupDialog-heading">Not on Twitter? Sign up, tune into the things you care about, and get updates as they happen.</h2>
          <div class="SignupDialog-form">
  <div class="signup SignupForm
    ">
    <a href="https://twitter.com/signup" role="button" class="EdgeButton EdgeButton--large EdgeButton--primary SignupForm-submit u-block js-signup " data-component="dialog" data-element="signup" style="color: #4287f5;">Sign up</a>
  </div>
          </div>
        </div>
        <div class="SignupDialog-footer modal-footer u-textCenter">
          Have an account? <a class="SignupDialog-signinLink" href="/login" rel="noopener">Log in »</a>
        </div>
      </div>
    </div>
  </div>
  
    <div id="sms-codes-dialog" class="modal-container">
    <div class="modal modal-medium draggable">
      <div class="modal-content">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
        <div class="modal-header">
          <h3 class="modal-title">Two-way (sending and receiving) short codes:</h3>
        </div>
        <div class="modal-body">
          
  <table id="sms_codes" cellpadding="0" cellspacing="0">
    <thead>
      <tr>
        <th>Country</th>
        <th>Code</th>
        <th>For customers of</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>United States</td>
        <td>40404</td>
        <td>(any)</td>
      </tr>
      <tr>
        <td>Canada</td>
        <td>21212</td>
        <td>(any)</td>
      </tr>
      <tr>
        <td>United Kingdom</td>
        <td>86444</td>
        <td>Vodafone, Orange, 3, O2</td>
      </tr>
      <tr>
        <td>Brazil</td>
        <td>40404</td>
        <td>Nextel, TIM</td>
      </tr>
      <tr>
        <td>Haiti</td>
        <td>40404</td>
        <td>Digicel, Voila</td>
      </tr>
      <tr>
        <td>Ireland</td>
        <td>51210</td>
        <td>Vodafone, O2</td>
      </tr>
      <tr>
        <td>India</td>
        <td>53000</td>
        <td>Bharti Airtel, Videocon, Reliance</td>
      </tr>
      <tr>
        <td>Indonesia</td>
        <td>89887</td>
        <td>AXIS, 3, Telkomsel, Indosat, XL Axiata</td>
      </tr>
      <tr>
        <td rowspan="2">Italy</td>
        <td>4880804</td>
        <td>Wind</td>
      </tr>
      <tr>
        <td>3424486444</td>
        <td>Vodafone</td>
      </tr>
    </tbody>
    <tfoot>
      <tr>
        <td colspan="3">
          » <a class="js-initial-focus" target="_blank" href="http://support.twitter.com/articles/14226-how-to-find-your-twitter-short-code-or-long-code" rel="noopener">See SMS short codes for other countries</a>
        </td>
      </tr>
    </tfoot>
  </table>
        </div>
      </div>
    </div>
  </div>
  
  <div id="leadgen-confirm-dialog" class="modal-container">
    <div class="modal draggable">
      <div class="modal-content">
        <button type="button" class="modal-btn modal-close js-close">
    <span class="Icon Icon--close Icon--medium">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
        <div class="modal-header">
          <h3 class="modal-title">Confirmation</h3>
        </div>
        <div class="modal-body">
          <div class="leadgen-card-container">
            <div class="media">
              <iframe class="cards2-promotion-iframe" scrolling="no" frameborder="0" src="">
              </iframe>
            </div>
          </div>
          <div class="js-macaw-cards-iframe-container" data-card-name="promotion">
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
  <div id="auth-webview-dialog" class="AuthWebViewDialog modal-container">
    <div class="modal draggable">
      <div class="modal-content">
        <button type="button" class="modal-btn modal-close modal-close-fixed js-close">
    <span class="Icon Icon--close Icon--large">
      <span class="visuallyhidden">Close</span>
    </span>
  </button>
  
        <div class="modal-header">
          <h3 class="modal-title">&nbsp;</h3>
        </div>
        <div class="modal-body">
          <div class="auth-webview-view-container">
            <div class="media">
              <iframe class="auth-webview-card-iframe js-initial-focus" scrolling="no" frameborder="0" width="590px" height="500px" src="">
              </iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
  
  <div id="promptbird-modal-prompt" class="modal-container">
    <div class="modal">
      
      <button type="button" class="modal-btn js-promptDismiss modal-close js-close">
        <span class="Icon Icon--close Icon--medium">
          <span class="visuallyhidden">Close</span>
        </span>
      </button>
      <div class="modal-content"></div>
    </div>
  </div>
  
  
  <div id="ui-walkthrough-dialog" class="modal-container UIWalkthrough">
    <div class="UIWalkthrough-clickBlocker"></div>
    <div class="modal modal-small">
      <div class="UIWalkthrough-caret"></div>
      <div class="modal-content">
        <div class="modal-body">
          <div class="UIWalkthrough-header">
            <span class="UIWalkthrough-stepProgress"></span>
            <button class="UIWalkthrough-skip js-close">
              Skip all
            </button>
          </div>
          
  
  
  
  <div class="UIWalkthrough-step UIWalkthrough-step--welcome">
    <h3 class="UIWalkthrough-title">
      <span class="Icon Icon--home UIWalkthrough-icon"></span>
      Welcome home!
    </h3>
    <p class="UIWalkthrough-message">This timeline is where you’ll spend most of your time, getting instant updates about what matters to you.</p>
  </div>
  
  
  
  <div class="UIWalkthrough-step UIWalkthrough-step--unfollow">
    <h3 class="UIWalkthrough-title">
      <span class="Icon Icon--smileRating1Fill UIWalkthrough-icon"></span>
      Tweets not working for you?
    </h3>
    <p class="UIWalkthrough-message">
      Hover over the profile pic and click the Following button to unfollow any account.
    </p>
  </div>
  
  <div class="UIWalkthrough-step UIWalkthrough-step--like">
  
    <h3 class="UIWalkthrough-title">
      <span class="Icon Icon--heart UIWalkthrough-icon"></span>
      Say a lot with a little
    </h3>
    <p class="UIWalkthrough-message">
      When you see a Tweet you love, tap the heart — it lets  the person who wrote it know you shared the love.
    </p>
  </div>
  
  <div class="UIWalkthrough-step UIWalkthrough-step--retweet">
    <h3 class="UIWalkthrough-title">
      <span class="Icon Icon--retweet UIWalkthrough-icon"></span>
      Spread the word
    </h3>
    <p class="UIWalkthrough-message">
      The fastest way to share someone else’s Tweet with your followers is with a Retweet. Tap the icon to send it instantly.
    </p>
  </div>
  
  <div class="UIWalkthrough-step UIWalkthrough-step--reply">
    <h3 class="UIWalkthrough-title">
      <span class="Icon Icon--reply UIWalkthrough-icon"></span>
      Join the conversation
    </h3>
    <p class="UIWalkthrough-message">
      Add your thoughts about any Tweet with a Reply. Find a topic you’re passionate about, and jump right in.
    </p>
  </div>
  
  
  
  <div class="UIWalkthrough-step UIWalkthrough-step--trends">
    <h3 class="UIWalkthrough-title">
      <span class="Icon Icon--discover UIWalkthrough-icon"></span>
      Learn the latest
    </h3>
    <p class="UIWalkthrough-message">
      Get instant insight into what people are talking about now.
    </p>
  </div>
  
  <div class="UIWalkthrough-step UIWalkthrough-step--wtf">
    <h3 class="UIWalkthrough-title">
      <span class="Icon Icon--follow UIWalkthrough-icon"></span>
      Get more of what you love
    </h3>
    <p class="UIWalkthrough-message">
      Follow more accounts to get instant updates about topics you care about.
    </p>
  </div>
  
  <div class="UIWalkthrough-step UIWalkthrough-step--search">
    <h3 class="UIWalkthrough-title">
      <span class="Icon Icon--search UIWalkthrough-icon"></span>
      Find what's happening
    </h3>
    <p class="UIWalkthrough-message">
      See the latest conversations about any topic instantly.
    </p>
  </div>
  
  <div class="UIWalkthrough-step UIWalkthrough-step--moments">
    <h3 class="UIWalkthrough-title">
      <span class="Icon Icon--lightning UIWalkthrough-icon"></span>
      Never miss a Moment
    </h3>
    <p class="UIWalkthrough-message">
      Catch up instantly on the best stories happening as they unfold.
    </p>
  </div>
        </div>
  
        <div class="modal-footer">
          <button class="EdgeButton EdgeButton--tertiary u-floatLeft plain-btn UIWalkthrough-button js-previous-step">Back</button>
          <button class="EdgeButton EdgeButton--secondary UIWalkthrough-button js-next-step js-initial-focus">Next</button>
        </div>
      </div>
    </div>
  </div>
  
  
  
  
  <div id="create-custom-timeline-dialog" class="modal-container"></div>
  <div id="edit-custom-timeline-dialog" class="modal-container"></div>
  <div id="curate-dialog" class="modal-container"></div>
  <div id="media-edit-dialog" class="modal-container"></div>
  
  
        <div class="PermalinkOverlay PermalinkOverlay-with-background " id="permalink-overlay">
    <div class="PermalinkProfile-dismiss modal-close-fixed">
      <span class="Icon Icon--close"></span>
    </div>
    <button class="PermalinkOverlay-next PermalinkOverlay-button u-posFixed js-next" type="button">
      <span class="Icon Icon--caretLeft Icon--large"></span>
      <span class="u-hiddenVisually">Next Tweet from user</span>
    </button>
    <div class="PermalinkOverlay-modal">
      <div class="PermalinkOverlay-spinnerContainer u-hidden">
        <div class="PermalinkOverlay-spinner"></div>
      </div>
      <div class="PermalinkOverlay-content">
        <div class="PermalinkOverlay-body">
        </div>
      </div>
    </div>
  </div>
  
      <div class="hidden" id="hidden-content">
    <iframe aria-hidden="true" class="tweet-post-iframe" name="tweet-post-iframe"></iframe>
    <iframe aria-hidden="true" class="dm-post-iframe" name="dm-post-iframe"></iframe>
  
  </div>
  </body>
</html>
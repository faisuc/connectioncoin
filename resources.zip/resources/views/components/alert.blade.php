<div class="alert alert-{{ $type ?? 'success' }} alert-block">
    <div class="alert-title">{{ $slot }}</div>
</div>